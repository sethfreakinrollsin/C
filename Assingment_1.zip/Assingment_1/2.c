//2. Accept an array and display it in reverse order.

//Header Files
#include<stdio.h>
#include<stdlib.h>

//Static Memory Allocation
int create_static(){
	
	//Variables
	int array[20],limit,i;
	
	//Limit
	printf("Static Memory Allocation\nEnter Limit [MAX: 20] :\n");
	scanf("%d",&limit);
	
	//Input
	for(i=0;i<limit;i++){	
		printf("Index [%d] :",i);
		scanf("%d",&array[i]);
	}

	//Output
	for(i=limit-1;i>-1;i--){
		printf("Index [%d] : %d \n",i,array[i]);
	}

return 0;
}


//Dynamic Memory Allocation
int create_dynamic(){
	
	//Variables
	int *ptr,limit,i;
	
	//Limit
	printf("Dynamic Memory Allocation \nEnter Limit : \n");
	scanf("%d",&limit);

	//Memory Allocation
	ptr=(int*)malloc(sizeof(int)*limit);
	
	//Input
	for(i=0;i<limit;i++){
		printf("Index  [%d] : ",i);
		scanf("%d",&ptr[i]);
	}

	//Output
	for(i=limit-1;i>-1;i--){
		printf("Index  [%d] : %d\n",i,ptr[i]);		
	}

return 0;
}

int main(){

	//Static
	create_static();

	//Dynamic
	create_dynamic();

return 0;
}
