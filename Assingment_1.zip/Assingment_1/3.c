//3. Accept an array and calculate the sum and multiplication of all the array elements.


//Header Files
#include<stdio.h>
#include<stdlib.h>


//Static Memory Allocation
int create_static(){
	
	//Variables
	int array[20],limit,i,sum=0,mul=1;
	
	//Limit
	printf("Static Memory Allocation\nEnter Limit [MAX: 20] :\n");
	scanf("%d",&limit);
	
	//Input
	for(i=0;i<limit;i++){	
		printf("Index [%d] :",i);
		scanf("%d",&array[i]);
	}

	//Processing
	for(i=0;i<limit;i++){
		
		//Sum
		sum+=array[i];
		
		//Multiply
		mul*=array[i];
	}
	
	//Output
	printf("The Sum of Elements is : %d \nThe Multiplication of Elements is  : %d \n",sum,mul);

return 0;
}


//Dynamic Memory Allocation
int create_dynamic(){
	
	//Variables
	int *ptr,limit,i,sum=0,mul=1;
	
	//Limit
	printf("Dynamic Memory Allocation \nEnter Limit : \n");
	scanf("%d",&limit);

	//Memory Allocation
	ptr=(int*)malloc(sizeof(int)*limit);
	
	//Input
	for(i=0;i<limit;i++){
		printf("Index  [%d] : ",i);
		scanf("%d",&ptr[i]);
	}

	//Processing
	for(i=0;i<limit;i++){
		
		//Sum		
		sum+=ptr[i];
		
		//Multiply
		mul*=ptr[i];
	}

	//Output
	printf("The Sum of the elements is  %d.\nThe Multiplication of the elements is  %d\n",sum,mul);

return 0;
}


//Main 
int main(){

	//Static
	create_static();

	//Dynamic
	create_dynamic();

return 0;
}
