//5.Accept an array and remove the duplicates.
//	Ex: 1,1,2,3,4,4
//	output : 1,2,3,4


//Header Files
#include<stdio.h>
#include<stdlib.h>

//Static Memory Allocation
int create_static(){
	
	//Variables
	int array[20],limit,i,j,k;
	
	//Limit
	printf("Static Memory Allocation\nEnter Limit [MAX: 20] :\n");
	scanf("%d",&limit);
	
	//Input
	for(i=0;i<limit;i++){	
		printf("Index [%d] :",i);
		scanf("%d",&array[i]);
	}

	//Processing
	for(i=0;i<limit;i++){
		for(j=i+1;j<limit;j++){
			if(array[i]==array[j]){
				printf("%d= %d \n",array[i],array[j]);
				if(array[j]==0){
					break;
				}
					//Re allocating the duplicate index
					for(k=0;k<limit;k++){	
						array[j]=array[j+1];
					}
			}
		}
	}


	//Output
	for(i=0;i<limit;i++){
			printf("%d  ",array[i]);
	}

return 0;
}


//Dynamic Memory Allocation
int create_dynamic(){
	
	//Variables
	int *ptr,limit,i,j,k;
	
	//Limit
	printf("Dynamic Memory Allocation \nEnter Limit : \n");
	scanf("%d",&limit);

	//Memory Allocation
	ptr=(int*)malloc(sizeof(int)*limit);
	
	//Input
	for(i=0;i<limit;i++){
		printf("Index  [%d] : ",i);
		scanf("%d",&ptr[i]);
	}

		//Processing
	for(i=0;i<limit;i++){
		for(j=i+1;j<limit;j++){
			if(ptr[i]==ptr[j]){
				printf("%d= %d \n",ptr[i],ptr[j]);
				if(ptr[j]==0){
					break;
				}
					//Re allocating the duplicate index
					for(k=0;k<limit;k++){	
						ptr[j]=ptr[j+1];
					}
			}
		}
	}


	//Output
	for(i=0;i<limit;i++){
			printf("%d  ",ptr[i]);
	}


return 0;
}

//Main
int main(){

	//Static
	create_static();

	//Dynamic
	create_dynamic();

return 0;
}
