// 4.Accept an array and find out the count of duplicate elements.
//	Ex: 1,1,2,3,4,4
//	output : 2


//Header Files
#include<stdio.h>
#include<stdlib.h>

//Static Memory Allocation
int create_static(){
	
	//Variables
	int array[20],limit,i,j,count=0;
	
	//Limit
	printf("Static Memory Allocation\nEnter Limit [MAX: 20] :\n");
	scanf("%d",&limit);
	
	//Input
	for(i=0;i<limit;i++){	
		printf("Index [%d] :",i);
		scanf("%d",&array[i]);
	}

	//Processing
	for(i=0;i<limit;i++){
		if(array[i]!=-1){
			for(j=i+1;j<limit;j++){
				if(array[i]==array[j]){
					printf("%d = %d\n",array[i],array[j]);
					array[i]=-1;
				}
		}
		}
	}

	//Counting Duplicates 
	for(i=0;i<limit;i++){
		if(array[i]==-1){
			count++;
		}
	}

	//Output
	printf("The Total Number of Duplicates is %d\n",count);

return 0;
}


//Dynamic Memory Allocation
int create_dynamic(){
	
	//Variables
	int *ptr,limit,i,j,count=0;
	
	//Limit
	printf("Dynamic Memory Allocation \nEnter Limit : \n");
	scanf("%d",&limit);

	//Memory Allocation
	ptr=(int*)malloc(sizeof(int)*limit);
	
	//Input
	for(i=0;i<limit;i++){
		printf("Index  [%d] : ",i);
		scanf("%d",&ptr[i]);
	}


	//Processing
	for(i=0;i<limit;i++){
		if(ptr[i]!=-1){
			for(j=i+1;j<limit;j++){
				if(ptr[i]==ptr[j]){
					printf("%d = %d\n",ptr[i],ptr[j]);
					ptr[i]=-1;
				}
		}
		}
	}

	//Counting Duplicates
	for(i=0;i<limit;i++){
		if(ptr[i]==-1){
			count++;
		}
	}

	//Output
	printf("The Total Number of Duplicates is %d\n",count);

return 0;
}

//Main
int main(){

	//Static
	create_static();

	//Dynamic
	create_dynamic();

return 0;
}
