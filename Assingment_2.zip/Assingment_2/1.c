//1.Accept the following details of N students such as Name, PRN, 
//Percentage using a structure and display it using Structure.

//Header
#include <stdio.h>

//Structure : Student 
struct student{
	char name[100];
	long prn;
	float percentage;
};


//Main
int main(){
	 //Variables
	int n,i;

	
	//No of Students 'n'
	printf("Enter Number of Students : ");
	scanf("%d",&n);

	//Structure Pointer
	struct student s[n];
	
	
	//Input
	for(i=0;i<n;i++){
		printf("Enter Name of Student %d : ",i+1);
		scanf(" %[^\n]s ",s[i].name);

		printf("Enter PRN of %s : ",s[i].name);
		scanf("%ld",&s[i].prn);

		printf("Enter Percentage of %s : ",s[i].name);
		scanf("%f",&s[i].percentage);
	}

	//Output
	for(i=0;i<n;i++){
		printf("\nStudent %d\nFull Name : %s \n PRN : %ld \n  Percentage : %f \n",i+1,s[i].name,s[i].prn,s[i].percentage);
	}	
	

return 0;
}
