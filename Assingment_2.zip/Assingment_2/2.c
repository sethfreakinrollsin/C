//2. Accept the following details of N Employees such as Employee Id, Date of Joining, Date of Birth, First name, Last name, Salary.
//Implement the structure using pointers using structure ( nested structure ) and display the details in a proper format.

//Header
#include<stdio.h>
#include<stdlib.h>

//Stucture Date
struct Date{
	int date,month,year;
};

//Structure Employee
struct employee{
	long empid;
	//DOJ/B - Date Of Joining/Birth 
	struct Date DOJ,DOB; 
	char first_name[30],last_name[30];
	float salary;
};


//Main
int main(){
	//Variables
	int i, n;
	
	//No. of Employees - n
	printf("Enter Number Of Employees : ");
	scanf("%d",&n);

	//Stucture of employee
	struct employee *emp;

	//Memory Allocation
	emp=(struct employee*)malloc(sizeof(struct employee)*n);
	//Input
	for(i=0;i<n;i++){
		printf("Enter First Name  of %d : ",i+1);
		scanf("%s",emp[i].first_name);

		printf("Enter Last Name of %s : ",emp[i].first_name);
		scanf(" %[^\n]s ",emp[i].last_name);
		
		printf("Enter Employee ID   of %s %s : ",emp[i].first_name,emp[i].last_name);
                scanf("%ld",&emp[i].empid);

		printf("Enter Date Of Birth (DOB) in DD/MM/YYYY : ");
		scanf("%d",&emp[i].DOB.date);
		scanf("%d",&emp[i].DOB.month);
		scanf("%d",&emp[i].DOB.year);

		printf("Enter Date Of Joining (DOJ) in DD/MM/YYYY : ");
                scanf("%d",&emp[i].DOJ.date);
                scanf("%d",&emp[i].DOJ.month);
                scanf("%d",&emp[i].DOJ.year);
	
		printf("Enter Salary  : ");
                scanf("%f",&emp[i].salary);

	}
	
	//Output
	printf("Sno||\t Emp ID \t||\tFirst Name\t||\tLast Name\t||  \t   DOB\t    || \t  DOJ   \t   ||    Salary\n");
	for(i=0;i<n;i++){
		printf("%2d || %17ld || %20s || %20s || %3d / %3d / %3d || %3d / %3d / %3d    ||   %f \n",i+1,emp[i].empid,emp[i].first_name,emp[i].last_name,emp[i].DOB.date,emp[i].DOB.month,emp[i].DOB.year,emp[i].DOJ.date,emp[i].DOJ.month,emp[i].DOJ.year,emp[i].salary);

	}

return 0;
}
